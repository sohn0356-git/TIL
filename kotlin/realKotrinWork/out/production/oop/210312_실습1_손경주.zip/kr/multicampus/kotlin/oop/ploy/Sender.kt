package kr.multicampus.kotlin.oop.ploy

open class Sender(var name:String) {
    open fun send(){
         println("하는일 없음")
    }
}